import { Controller } from '@nestjs/common';

@Controller('health')
export class HealthController {}
